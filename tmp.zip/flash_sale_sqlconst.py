# -*- coding: utf-8 -*-

import const

const.SEL_FLASH_SALE = '''
    SELECT
      T1.item_id
      , T2.item_nm
      , T2.image
      , T1.categ_x
      , T1.categ_y
      , T3.point_x
      , T3.point_y
      , T1.price
      , T1.quantity
    FROM
        flash_sale T1
        INNER JOIN item T2
        ON  T1.item_id = T2.item_id
        INNER JOIN item_kbn T3
        ON  T2.kbn = T3.kbn
'''
const.INS_FLASH_SALE_HIST = '''
    INSERT INTO flash_sale_hist
    (
        item_id,
        flash_sale_price,
        sale_quantity,
        sale_price
    )
    VALUES
    (
        :item_id,
        :flash_sale_price,
        :sale_quantity,
        :sale_price
    )
'''
