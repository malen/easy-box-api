-- ���7����Ʒ�۸�̬
SELECT
    T1.item_id,
    T1.daily,
    T2.item_nm,
    T1.cost_lowest,
    T1.cost_avg,
    T1.cost_best,
    T1.price_lowest,
    T1.price_avg,
    T1.price_best
FROM
    daily_item T1
    INNER JOIN item T2
    ON T1.item_id = T2.item_id
WHERE
    T1.daily > date ('now', '-7 days', 'localtime')
ORDER BY
    T1.item_id,
    T1.daily


SELECT
    T02.recipe_id,
    T02.recipe_nm `��Ʒ`,
    T02.item_id,
    T02.item_nm `ԭ��`,
    T01.cost_avg `��λƽ���ɱ�`,
    T02.amount `����`,
    T01.cost_avg * T02.amount `ƽ���ɱ�`,
    T01.price_avg `��λƽ������`,
    ROUND((T01.price_avg - T01.cost_avg), 2) `��λƽ������`
FROM
    daily_item T01
    INNER JOIN (
        SELECT
            T1.recipe_id,
            T2.item_nm recipe_nm,
            T1.item_id,
            T1.item_nm,
            T1.amount,
            T1.orderby
        FROM
            recipe T1
            LEFT JOIN item T2
            ON  T2.item_id = T1.recipe_id
    ) T02
ON T01.item_id = T02.item_id
AND T01.daily = date('now', '0 days', 'localtime')
ORDER BY
    T02.recipe_id,
    T02.orderby
