# -*- coding: utf-8 -*-

import const

##############################################################################
#
#  CREATE TABLE
#
##############################################################################
# 用户
const.CREATE_USER = '''
    CREATE TABLE IF NOT EXISTS user (
        user_id integer NOT NULL,
        user_name varchar(20) NOT NULL,
        PRIMARY KEY(user_id)
    )
'''
const.CREATE_ENV = '''
    CREATE TABLE IF NOT EXISTS env (
        user_id integer NOT NULL,
        env_key varchar(20) NOT NULL,
        env_nm varchar(20) NOT NULL,
        PRIMARY KEY(user_id, env_key)
    )
'''
# 区分
const.CREATE_ITEM_KBN = '''
    CREATE TABLE IF NOT EXISTS item_kbn (
        kbn char(4) NOT NULL,       -- 0100 后两位00的是大分类
        kbn_nm varchar(20),
        kbn_img varchar(30),
        point_x integer,
        point_y integer,
        scan_flg char(1),
        PRIMARY KEY(kbn)
    )
'''
# 商品
const.CREATE_ITEM = '''
    CREATE TABLE IF NOT EXISTS item (
        item_id char(6) NOT NULL,
        item_nm varchar(20) NOT NULL,
        kbn char(4) NOT NULL,
        price_critical integer,
        --booth_fee integer,          -- 摊位费=卖价 X 1% 跟商品卖价相关，所以从商品表删除
        pkg_num integer,
        image varchar(30),
        career varchar(30),           -- 所属职业:所有
        scan_flg char(1),
        ins_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        upd_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        PRIMARY KEY(item_id)
    )
'''
const.CREATE_RECIPE = '''
    CREATE TABLE IF NOT EXISTS  recipe (
        recipe_id char(6) NOT NULL,
        item_id char(6) NOT NULL,
        item_nm varchar(20),
        amount integer,
        orderby integer,
        PRIMARY KEY(recipe_id, orderby)
    )
'''
const.CREATE_COLLE_ITEM = '''
    CREATE TABLE IF NOT EXISTS colle_item (
        item_id char(6) NOT NULL,
        colle_date date NOT NULL DEFAULT (date('now', '-1 hours', 'localtime')),
        colle_times integer NOT NULL DEFAULT 1,
        colle_price integer,
        colle_quantity integer,
        colle_img varchar(30),
        unit_price integer,
        ins_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        upd_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        PRIMARY KEY(item_id, colle_date, colle_times)
    )
'''
const.CREATE_DAILY_ITEM = '''
    CREATE TABLE IF NOT EXISTS daily_item (
        item_id char(6) NOT NULL,
        daily date NOT NULL,
        cost_lowest real,           -- 最低成本
        cost_avg real,              -- 平均成本
        cost_best real,             -- 最高成本
        price_lowest real,          -- 最低卖价
        price_avg real,             -- 平均卖价
        price_best real,            -- 最高卖价
        daily_hot_rank integer,     -- 热卖度
        ins_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        upd_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime')),
        PRIMARY KEY(item_id, daily)
    )
'''
const.CREATE_FLASH_SALE = '''
    CREATE TABLE IF NOT EXISTS flash_sale (
        item_id char(6) NOT NULL,
        kbn char(4) NOT NULL,
        x integer,
        y integer,
        price real NOT NULL,        -- 抢购单价
        quantity integer,           -- 抢购数量
        PRIMARY KEY(item_id)
    )
'''
const.CREATE_FLASH_SALE_HIST = '''
    CREATE TABLE IF NOT EXISTS flash_sale_hist (
        item_id char(6) NOT NULL,
        flash_sale_price real NOT NULL,
        sale_quantity integer,
        sale_price integer,
        sale_date datetime NOT NULL DEFAULT (datetime('now', '-1 hours', 'localtime'))
    )
'''
##############################################################################
#  功能
##############################################################################
# 获取当日指定商品的数据采集次数
const.SEL_COLLE_ITEM_MAXTIMES = '''
    SELECT
        MAX(colle_times) max_times
    FROM
        colle_item
    WHERE
            item_id = ?
        AND colle_date = date('now', '-1 hours', 'localtime')
'''
# 将采集的商品数据插入数据库
const.INS_COLLE_ITEM = '''
    INSERT INTO colle_item
    (
        item_id,
        colle_times,
        colle_price,
        colle_quantity,
        colle_img,
        unit_price
    )
    VALUES
    (?, ?, ?, ?, ?, ?)
'''
const.SEL_ITEM_KBN = '''
    SELECT
        kbn,
        kbn_nm,
        point_x,
        point_y
    FROM
        item_kbn
    WHERE
        scan_flg = '1'
'''
# 获取指定区分的所有商品
const.SEL_ITEM_BY_KBN = '''
    SELECT
        item_id,
        item_nm,
        image
    FROM
        item
    WHERE
        kbn = ?
    AND scan_flg = '1'
'''
# 日别商品卖价情报作成
const.SEL_COLLE_ITEM = '''
    SELECT
        item_id,
        colle_date,
        MIN(unit_price) min_val,
        ROUND(AVG(unit_price), 2) avg_val,
        MAX(unit_price) max_val
    FROM
        colle_item
    WHERE
        colle_date=date('now', '-1 hours', 'localtime')
    AND unit_price != 0
    GROUP BY
        item_id
'''
const.EXISTS_DAILY_ITEM = '''
    SELECT
        COUNT(1)
    FROM
        daily_item
    WHERE
        item_id = ?
    AND daily = ?
'''
const.INS_DAILY_ITEM = '''
    INSERT INTO daily_item
    (
        item_id,
        daily,
        cost_lowest,
        cost_avg,
        cost_best,
        price_lowest,
        price_avg,
        price_best
    )
    VALUES
    (
        :item_id,
        :daily,
        :min_val,
        :avg_val,
        :max_val,
        :min_val,
        :avg_val,
        :max_val
    )
'''
const.UPD_DAILY_ITEM = '''
    UPDATE daily_item
    SET
        cost_lowest = :min_val,
        cost_avg = :avg_val,
        cost_best = :max_val,
        price_lowest = :min_val,
        price_avg = :avg_val,
        price_best = :max_val,
        upd_date = datetime('now', '-1 hours', 'localtime')
    WHERE
        item_id = :item_id
    AND daily = :daily
'''
# 更新日别商品卖价情报(recipe)
const.SEL_DAILT_ITEM_WITH_RECIPE = '''
    WITH recipe_tmp AS(
        SELECT
            T1.item_id,
            T2.item_id item_id2,
            T2.amount
        FROM
            item T1
            INNER JOIN recipe T2
            ON  T1.item_id=T2.recipe_id
    )
    SELECT
        T0.item_id,
        T1.daily,
        SUM(T1.price_lowest * T0.amount) cost_lowest,
        SUM(T1.price_avg * T0.amount) cost_avg,
        SUM(T1.price_best * T0.amount) cost_best
    FROM
        recipe_tmp T0
        INNER JOIN daily_item T1
        ON  T0.item_id2 = T1.item_id
        INNER JOIN item T2
        ON  T1.item_id = T2.item_id
        AND T1.daily = date('now', '-1 hours', 'localtime')
    GROUP BY
        T0.item_id
'''
const.UPD_DAILY_ITEM_WITH_RECIPE = '''
    UPDATE daily_item
    SET
        cost_lowest = ?,
        cost_avg = ?,
        cost_best = ?,
        upd_date = datetime('now', '-1 hours', 'localtime')
    WHERE
        item_id = ?
    AND daily = ?
'''
##########################################################################
#
##########################################################################
const.SEL_PROFIT_FROM_DAILY_ITEM = '''
    SELECT
        T1.item_id,
        T2.item_nm,
        (price_avg - cost_avg) profit
    FROM
        daily_item T1
        LEFT JOIN item T2
        ON  T1.item_id = T2.item_id
    WHERE
        profit > 0
'''
const.SEL_RECIPE_PRICE = '''
    SELECT
        T02.recipe_id,
        T02.recipe_nm,
        T02.item_id,
        T02.item_nm,
        T01.cost_avg,
        T02.amount,
        T01.cost_avg * T02.amount total,
        T01.price_avg,
        ROUND((T01.price_avg - T01.cost_avg), 2) profit
    FROM
        daily_item T01
        INNER JOIN (
            SELECT
                T1.recipe_id,
                T2.item_nm recipe_nm,
                T1.item_id,
                T1.item_nm,
                T1.amount,
                T1.orderby
            FROM
                recipe T1
                INNER JOIN item T2
                ON T2.item_id = T1.recipe_id
        ) T02
    ON T01.item_id = T02.item_id
    AND T01.daily = date('now', '-1 hours', 'localtime')
    ORDER BY
        T02.recipe_id,
        T02.orderby
'''
