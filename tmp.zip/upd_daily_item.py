# -*- coding: utf-8 -*-
import os
import sqlite3
from sqlite3 import Error
from contextlib import closing
from sqlconst import const


##############################################################################
# 数据库连接，并指定row_factory
##############################################################################
def create_conn():
    try:
        db_file = os.path.join(os.getcwd(), "aftertomorrow.db")
        conn = sqlite3.connect(db_file, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn
    except Error as e:
        print(e)
    return None


##############################################################################
# 主处理
##############################################################################
if __name__ == '__main__':

    with closing(create_conn()) as conn:
        cur = conn.cursor()
        cur.execute("BEGIN TRANSACTION")
        # replace 文有坑，会删除原有记录，重新插入
        # cur.execute(const.REP_DAILY_ITEM)

        cur.execute(const.SEL_COLLE_ITEM)
        rows = cur.fetchall()
        for row in rows:
            data = {
                'item_id': row['item_id'],
                'daily': row['colle_date'],
                'min_val': row['min_val'],
                'avg_val': row['avg_val'],
                'max_val': row['max_val'],
            }

            cur.execute(const.EXISTS_DAILY_ITEM,
                        (
                            data['item_id'],
                            data['daily'])
                        )
            if cur.fetchone()[0] == 0:
                cur.execute(const.INS_DAILY_ITEM, data)
            else:
                cur.execute(const.UPD_DAILY_ITEM, data)

        cur.execute(const.SEL_DAILT_ITEM_WITH_RECIPE)
        rows = cur.fetchall()
        for row in rows:
            condition = (
                row['cost_lowest'],
                row['cost_avg'],
                row['cost_best'],
                row['item_id'],
                row['daily'],
            )
            cur.execute(const.UPD_DAILY_ITEM_WITH_RECIPE, condition)

        cur.execute("COMMIT")
