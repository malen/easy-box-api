import os
import time
import sqlite3
from sqlite3 import Error
from contextlib import closing
from collections import namedtuple
from sqlconst import const
import pyautogui as gui
import datetime
import cv2 as cv
import pyocr
import pyocr.builders
import numpy as np
from PIL import ImageGrab
from PIL import ImageOps


##############################################################################
# 主处理
##############################################################################
if __name__ == '__main__':
    gui.PAUSE = 2.5
    while True:
        gui.typewrite(['space'], interval=60)
