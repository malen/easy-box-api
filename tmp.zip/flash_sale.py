# -*- coding: utf-8 -*-

import os
import sqlite3
from sqlite3 import Error
from contextlib import closing
from flash_sale_sqlconst import const
import pyautogui as gui
import datetime
import cv2 as cv
import pyocr
import pyocr.builders
import numpy as np
from PIL import ImageGrab
from PIL import ImageOps

##############################################################################
# 数据库连接，并指定row_factory
##############################################################################


def create_conn():
    try:
        db_file = os.path.join(os.getcwd(), "aftertomorrow.db")
        conn = sqlite3.connect(db_file, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn
    except Error as e:
        print(e)
    return None


##############################################################################
# 根据指定的图片，在游戏中查找坐标
##############################################################################
def find_item(img_path):
    try:
        x, y = gui.locateCenterOnScreen(
            img_path, grayscale=True, confidence=.9)
        return x, y
    except Exception:
        gui.moveTo(1167, 463)
        gui.scroll(-10)
        try:
            x, y = gui.locateCenterOnScreen(
                img_path, grayscale=True, confidence=.9)
            return x, y
        except Exception as ex1:
            print(ex1)
            return 0, 0


def get_ocr_tool():
    # 调用opencv进行识别
    tools = pyocr.get_available_tools()
    if len(tools) == 0:
        print("No OCR tool found")
        return None
    tool = tools[0]
    print("Will use tool '%s'" % (tool.get_name()))
    langs = tool.get_available_languages()
    print("Available languages: %s" % ", ".join(langs))
    return tool


def depoint(img):
    """传入二值化后的图片进行降噪"""
    pixdata = img.load()
    w, h = img.size
    for y in range(1, h - 1):
        for x in range(1, w - 1):
            count = 0
            if pixdata[x, y - 1] > 205:
                count = count + 1
            if pixdata[x, y + 1] > 205:
                count = count + 1
            if pixdata[x - 1, y] > 205:
                count = count + 1
            if pixdata[x + 1, y] > 205:
                count = count + 1
            if pixdata[x - 1, y - 1] > 205:
                count = count + 1
            if pixdata[x - 1, y + 1] > 205:
                count = count + 1
            if pixdata[x + 1, y - 1] > 205:
                count = count + 1
            if pixdata[x + 1, y + 1] > 205:
                count = count + 1
            if count > 6:  # 控制领域判定大小
                pixdata[x, y] = 255
    return img


def tesseract(tool, item_id, price):
    datas = []
    # 截取商品价格
    img = ImageGrab.grab(bbox=(740, 290, 740 + 230, 290 + 515))
    img = img.convert('L').point(lambda x: 0 if x < 218 else x)
    img = ImageOps.invert(img)
    img = depoint(img)

    img.save('flash_sale.png', dpi=(300, 300))

    img_rgb = cv.imread('flash_sale.png')
    img_gray = cv.cvtColor(img_rgb, cv.COLOR_BGR2GRAY)
    template = cv.imread('mark.png', 0)
    w, h = template.shape[::-1]
    res = cv.matchTemplate(img_gray, template, cv.TM_CCOEFF_NORMED)
    threshold = 0.8
    loc = np.where(res >= threshold)

    temp = 0
    for pt in zip(*loc[::-1]):
        cv.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0, 0, 255), 1)
        if abs(temp - pt[1]) < 10:
            continue
        img1 = img.crop((0, pt[1], pt[0], pt[1] + h))
        colle_quantity = tool.image_to_string(
            img1,
            lang='after',
            builder=pyocr.builders.DigitBuilder(tesseract_layout=7)
        )
        # 修正识别结果中间带空格的问题
        colle_quantity = int(''.join(colle_quantity.split()))

        img2 = img.crop((pt[0] + w, pt[1], 230, pt[1] + h))
        colle_price = tool.image_to_string(
            img2,
            lang='after',
            builder=pyocr.builders.DigitBuilder(tesseract_layout=7)
        )
        # 修正识别结果中间带空格的问题
        colle_price = int(''.join(colle_price.split()))

        print('{0} / {1}'.format(colle_quantity, colle_price))
        temp = pt[1]

        # 计算单价, 若单价为0，则需要手动确认采集数据是否正确
        unit_price = colle_price / colle_quantity
        if isinstance(unit_price, float):
            continue

        if unit_price <= price:
            gui.click(pt[0], pt[1])
            # 点击购买图片

            # 编辑数据
            data = {
                'item_id': item_id,
                'flash_sale_price': price,
                'sale_quantity': colle_quantity,
                'sale_price': colle_price
            }
            datas.append(data)

    return datas


if __name__ == '__main__':

    # 返回按钮
    back_x, back_y = 600, 260
    gui.PAUSE = 1.5

    tool = get_ocr_tool()
    curr_path = os.getcwd()

    with closing(create_conn()) as conn:
        cur = conn.cursor()
        # 资源定位
        cur.execute(const.SEL_FLASH_SALE)
        flash_datas = cur.fetchall()

        for data in flash_datas:
            cur.execute("BEGIN TRANSACTION")
            gui.click(data['categ_x'], data['categ_y'])
            gui.click(data['point_x'], data['point_y'])
            gui.moveTo(1090, 500)
            gui.scroll(10)

            path = os.path.join(curr_path, data['image'])
            if not os.path.exists(path):
                continue

            # 根据图片获取坐标
            x, y = find_item(path)
            if x == 0:
                continue

            # 点击对应图片，进入商品列表
            gui.click(x, y)

            datas = tesseract(tool, data['item_id'], data['price'])
            cur.execute(const.INS_FLASH_SALE_HIST, datas)
            gui.click(back_x, back_y)
            cur.execute("COMMIT")
